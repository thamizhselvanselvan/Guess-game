

// elements
const secretCodeEl = document.getElementById('secret-code');
const messageEl = document.getElementById('message');
const scoreEl = document.getElementById('score');
const highScoreEl = document.getElementById('high-score');

//variables
let secretCode;
let gameActionValue = 1;
let highScore = 0;
let score;

